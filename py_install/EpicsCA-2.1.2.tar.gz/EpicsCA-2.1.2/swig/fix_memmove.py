import sys

f  =  open(sys.argv[1],'r')
text = f.readlines()
f.close()

memmove_code ='''
static PyObject *_wrap_memmove(PyObject *self, PyObject *args) {
    PyObject *resultobj;
    void *arg1 = (void *) 0 ;
    void *arg2 = (void *) 0 ;
    int arg3 ;
    PyObject * obj0 = 0 ;
    PyObject * obj1 = 0 ;
    
    if(!PyArg_ParseTuple(args,(char *)"OO:memmove",&obj0,&obj1)) goto fail;
    if ((SWIG_ConvertPtr(obj0,(void **) &arg1, 0, SWIG_POINTER_EXCEPTION | 0 )) == -1) SWIG_fail;
    {
        arg2 = (void *) PyString_AsString(obj1);
        arg3 = (int) PyString_Size(obj1);
    }
    memmove(arg1,(void const *)arg2,arg3);
    
    Py_INCREF(Py_None); resultobj = Py_None;
    return resultobj;
    fail:
    return NULL;
}

'''

f   = open(sys.argv[1],'w')
for i in text:
    if i.find('_wrap_memmove(PyObject') > 2:
        f.write(memmove_code)
        i = i.replace('_wrap_memmove','_wrap_memmove3')
    f.write(i)
f.close()

