swig -python -Wall -O epics.i
python fix_memmove.py epics_wrap.c

