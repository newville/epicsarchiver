#!/usr/bin/python
# To use:
#       python setup.py install
#

# location of epics base and extension directories
def_epics_base = "/usr/local/epics/base"

# name of system libraries to use:
#   if left as an empty string, will be found from uname.
sysname   = "" # 


######################################################################
# location to install executables to
inst_bindir = "EpicsCA" 
version     = '2.1.2'
desc        = "Epics Channel Access Extensions to Python"

debug       = False

known_hosts = {'Linux':   ('linux-x86', 'linux-x86_64') ,
               'Darwin':  ('darwin-ppc','darwin-x86'),
               'Win32':   ('win32-x86', 'win32-x86_64'),
               'solaris': ('solaris-sparc',) }


#
def append_if_exists(l,d):
    if os.path.exists(d): l.append(d)

# check python version, verify that > 1.5
try:
    import os, sys, string, re
except:
    print "Error: python is broken"
    sys.exit(1)


if (float(sys.version.split()[0][:3]) < 2.0):
    print "Error: python is too old"
    sys.exit(1)

# check for distutils
try:
    import distutils
    from   distutils.core import setup, Extension
except:
    print " Error: cannot find Python's distutils."
    print " You may need to install the python distutils module"
    sys.exit(1)

# Unix
if (os.name == 'posix'):
    sysname  = os.uname()[0]
    syslibs  = ['m','c']

    try:
        epics_base = os.environ['EPICS_BASE']
    except KeyError:
        print "  Warning: could not find environment variable EPICS_BASE"
        print "           will try: " , def_epics_base
        epics_base = def_epics_base

    systags = [sysname]
    if (sysname in known_hosts.keys()):
        for i in known_hosts[sysname]: systags.append(i)
    
    # build list of directories to look for libs and include files
    dirs    = []
    if (epics_base is None or not os.path.isdir(epics_base)):
        print "  Warning: could not find  EPICS_BASE."
        print "  Please set EPICS_BASE environment variable to your Epics Base."
        sys.exit(1)
        
    dirs = [epics_base]

    incdirs = ['.']
    libdirs = ['.']

    for i in dirs:
        append_if_exists(incdirs,"%s/include" % i)
        for s in systags:
            append_if_exists(incdirs,"%s/include/os/%s" % (i,s))
            append_if_exists(libdirs,"%s/lib/%s" % (i,s))

    ca_libs  = ['ca','Com','pthread']
    link_args = []
    macros   = []

# Windows (build with objects not libraries to avoid dll hell)
elif (os.name == 'nt'):
    #  Note that I'm using a cached copy of base for 3.14.7 -- seems to work!!.
    epics_base = "Windows\\epics_base" 
     
    incdirs = ['.',os.path.join(epics_base,'include')]
    for j in (('src','libCom'), ('src','ca'),('src','db'),('src','include'),
                 ('include','os','WIN32')):
        s = epics_base
        for i in j: s = os.path.join(s,i)
        append_if_exists(incdirs,s)

    macros = [('NDEBUG', None), ('WIN32', None), ('_CONSOLE', None),
              ('NO_STRICT', None), ('_NO_PROTO',None), ('__STDC__', '0'),
              ('_WIN32', None), ('_X86_', None),('NODEFAULTLIB',None)]

    link_args = ['ws2_32.lib', 'oldnames.lib', 'kernel32.lib',
                 'user32.lib', 'gdi32.lib', 'winspool.lib', 'comdlg32.lib',
                 'advapi32.lib', 'shell32.lib', 'ole32.lib', 'oleaut32.lib',
                 'netapi32.lib', 'uuid.lib', 'wsock32.lib', 'mpr.lib',
                 'winmm.lib', 'version.lib', 'odbc32.lib', 'odbccp32.lib',
                 'msvcrt.lib']
    # , '/NODEFAULTLIB']

    # 
    # the idea here is to find the ca and libCom objects to link
    # skipping over objects that have main() defined (kludgy!!)
    blacklist_objs = ['caRepeater.obj']
    for d in ('ca','libCom'):
        dir = os.path.join(epics_base,'src',d,'O.win32-x86')
        for f in  os.listdir(dir):
            if (f[-4:]=='.obj' and f.find('Main')==-1 and f not in blacklist_objs):
                link_args.append(os.path.join(dir,f))
                
    ca_libs = []
    libdirs = []
    incdirs.append("C:\\Python2.5\include") 


sources = [ 'epics_wrap.c'] 
if debug:
    print 'SETUP.PY incdirs  = ', incdirs
    print 'SETUP.PY libdirs  = ', libdirs
    print 'SETUP.PY linkargs = ', link_args

packages = ['EpicsCA','EpicsCA.wx']


setup (name             = "EpicsCA",
       author           = "Matt Newville", 
       author_email     = "newville@cars.uchicago.edu", 
       maintainer       = "Matt Newville",
       maintainer_email = "newville@cars.uchicago.edu",
       url              = "http://cars9.uchicago.edu/software/",
       license          = "Python license",
       description      = desc,
       long_description = desc,
       version          = version,
       include_dirs     = incdirs,
       ext_modules      = [Extension('_epics', sources,
                                     libraries    = ca_libs,
                                     library_dirs = libdirs,
                                     extra_link_args = link_args,
                                     define_macros=macros)],
       package_dir   = {'EpicsCA':'lib'},
       packages = ['EpicsCA','EpicsCA.wx']

       )
