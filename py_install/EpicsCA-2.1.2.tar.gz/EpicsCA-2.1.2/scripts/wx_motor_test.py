#!/usr/bin/python
#
# test the MotorPanel

import wx
import sys
from EpicsCA import caget
from EpicsCA.wx import MotorPanel, catimer, pvText, pvFloatCtrl, closure

ID_ABOUT = 101
ID_EXIT  = 102

def my_callback(value=None,**kw):
    print ">> my callback val = ", value
    for k,v in kw.items():
        print "my callback ", k, v

def read_motor_list(fname = 'testmotors.dat'):
    f = open(fname,'r')
    motors = {}
    names  = []
    for line in f.readlines():
        line = line[:-1].strip()
        if len(line)>2 and not line.startswith('#'):
            mname = line
            if mname.endswith('.VAL'): mname = mname[:-4]
            try:
                desc = caget("%s.DESC" % mname)
            except:
                desc = None

            if desc is None: desc = mname
            motors[desc] = mname
            names.append(desc)
    return names,motors

class MyFrame(wx.Frame):
    def __init__(self, parent, ID, *args,**kwds):

        ## kwds["style"] = wx.CAPTION|wx.MINIMIZE_BOX|wx.MAXIMIZE_BOX| wx.SYSTEM_MENU|wx.RESIZE_BORDER|wx.TAB_TRAVERSAL
        wx.Frame.__init__(self, parent, ID, '',
                         wx.DefaultPosition, wx.Size(-1,-1),**kwds)
        self.SetTitle(" Epics Motor example")

        self.CreateStatusBar(2,wx.CAPTION|wx.THICK_FRAME)
        self.SetStatusWidths([-5,-1])
        self.SetStatusText("This is the statusbar")
        self.SetFont(wx.Font(12,wx.SWISS,wx.NORMAL,wx.BOLD,False))
        menu = wx.Menu()
        menu.Append(ID_ABOUT, "&About",
                    "More information about this program")
        menu.AppendSeparator()
        menu.Append(ID_EXIT, "E&xit", "Terminate the program")

        menuBar = wx.MenuBar()
        menuBar.Append(menu, "&File");
        self.SetMenuBar(menuBar)

        wx.EVT_MENU(self, ID_ABOUT, self.OnAbout)
        wx.EVT_MENU(self, ID_EXIT,  self.OnExit)

        self.mainframe  = wx.BoxSizer(wx.VERTICAL)
        
        self.pane0 = wx.Panel(self, -1, size=(-1, -1))
        
        self.epics_timer = catimer(self)

        motor_choices,self.motors = read_motor_list()

        l1 = wx.StaticText(self.pane0, -1, "Motor:", size=(-1, -1),
                                     style=wx.RESIZE_BORDER)

        c1 = wx.Choice(self.pane0, -1, choices=motor_choices, size=(180, -1))
        c1.Bind(wx.EVT_CHOICE, closure(self.OnMotorChoice,motor='1'))

        l1.SetFont(wx.Font(14,wx.SWISS,wx.NORMAL,wx.NORMAL,False))
        c1.SetSelection(0)
        
        self.gs0 = wx.FlexGridSizer(1, 7, 5, 10)
        self.gs0.Add(l1, 0, wx.ALIGN_LEFT|wx.LEFT,5)
        self.gs0.Add(c1, 0, wx.ALIGN_LEFT)

        self.pane0.SetAutoLayout(1)
        self.pane0.SetSizer(self.gs0)
        self.gs0.Fit(self.pane0)

        self.mainframe.Add(self.pane0, 1, wx.EXPAND)

        self.motor1 = MotorPanel(self, messenger=self.write_message,
                                 timer = self.epics_timer)
        
        self.motor1.SelectMotor(self.motors[motor_choices[0]])
        
        self.mainframe.Add(self.motor1, 1,wx.ALIGN_LEFT|wx.EXPAND)

        self.SetSizer(self.mainframe)
        self.mainframe.Fit(self)
        self.Refresh()

    def write_message(self,text,status='normal'):
        self.SetSelfStatusText(text)

    def OnAbout(self, event):
        dlg = wx.MessageDialog(self, "This sample program shows off\n"
                              "frames, menus, statusbars, and this\n"
                              "message dialog.",
                              "About Me", wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()

    def OnMotorChoice(self,event,motor=None):
        self.motor1.SelectMotor(self.motors[event.GetString()])

    def OnExit(self, event):
        self.Close(True)
        self.Destroy()
        
if __name__ == '__main__':
    app = wx.PySimpleApp()
    f = MyFrame(None,-1)
    f.Show(True)
    app.MainLoop()


