#!/usr/bin/env python

import sys, getopt, time
import EpicsCA

doc = """usage:  caput PV value
   set a PVs value
"""

def show_usage():
    print doc
    sys.exit()

if len(sys.argv) < 3:  show_usage()

pvname = sys.argv[1]
value  = sys.argv[2]

try:
    p = EpicsCA.PV(pvname,connect=True,connect_time=2.0)
    EpicsCA.poll()
except KeyboardInterrupt:
    sys.exit()
except EpicsCA.EpicsCAError, msg:
    print msg
    sys.exit()

p.put(value)
