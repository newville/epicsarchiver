#!/usr/bin/python
#
# simple  caget
from EpicsCA import PV

import sys, getopt

__doc__ = """caget usage:  caget PV1 PV2 PV3 ..."""


def show_usage():
    print __doc__
    sys.exit()

try:
    opts, args = getopt.getopt(sys.argv[1:],
                               "hert:f:",
                               ["help", "type=","format=","raw","enhanced"])
except:
    show_usage()
if (len(args) == 0):  show_usage()

for key,val in opts:
    if key in ("-h", "--help"):
        show_usage()
        sys.exit()

for pv in args:
    p   = PV(pv)
    p.get()
    desc = ''
    dpv  = None
    if (pv[-4:] == '.VAL'):  dpv = "%s.DESC" % pv[:-4]
    if (dpv != None):
        d = PV(dpv)
        if (d.char_value != None): desc = "[%s]" % d.char_value
        d.disconnect()
        
    if (p.type == 'ENUM'):
        print "%s %s = %s (%s)" % (pv,desc,p.value,p.char_value)
    else:
        print "%s %s = %s " % (pv,desc,p.char_value)

    p.disconnect()
