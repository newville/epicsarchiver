#!/usr/bin/env python

import sys, getopt, time
import EpicsCA

doc = """usage:  cainfo PV
   print status information for a PV."""

def show_usage():
    print doc
    sys.exit(0)

if len(sys.argv) < 2:  show_usage()

for pvname in sys.argv[1:]:
    rpvname = pvname
    idot = pvname.find('.') 
    if idot < 1: idot = len(rpvname)
    rpvname =  "%s.RTYP" % pvname[:idot]    
        
    try:
        r = EpicsCA.PV(rpvname,connect=True, connect_time=2.0)
        rec = r.value
    except:
        rec = ' unkknown record type'
    try:
        p = EpicsCA.PV(pvname,connect=True, use_control=True, connect_time=2.0)
        EpicsCA.poll()
    except KeyboardInterrupt:
        break
    except EpicsCA.EpicsCAError, msg:
        print msg
        break


    print "== %s" % p.pvname
    print "   record type  =", rec
    if p.count==1:
        print '   value        =', p.value
    else:
        aval,ext,fmt = [],'',"%i,"
        if p.count>5: ext = '...'
        if p.type in  ('float','double'): fmt = "%g,"
        for i in range(min(5,p.count)):
            aval.append(fmt % p.value[i])
        print "   value        = array  [%s%s]" % ("".join(aval),ext)

    for i in ('char_value','count','type','units','precision','host','access',
              'status','severity', 'hlim','llim','display_hlim','display_llim'):
        s = str(getattr(p,i)) or 'None'
        print '   %.13s= %s' % (i+' '*16, s)

    # list enum strings
    if p.type == 'enum':
        print "   enum strings:"
        for i,s in enumerate(p.enum_strings): print "        %i=%s " % (i,s)

    print '=='
    p.disconnect()
    EpicsCA.pend_event()

