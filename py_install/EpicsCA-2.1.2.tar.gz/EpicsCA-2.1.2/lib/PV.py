#!/usr/bin/env python

import _epics
import exceptions
import math
import time
import types
from closure import closure


HAS_NUMPY= False
try:
    import numpy
    HAS_NUMPY  = True
except:
    pass
    
# define EpicsCAError exception
class EpicsCAError(exceptions.Exception):
    """ raised to indicate an error with EpicsCA """
    def __init__(self,args=None):
        self.args = args

def poll():
    """poll():   channel access poll  = pend_event(1.e-5)"""
    return _epics.pend_event(1.e-5)

def pend_io(t=1.0):
    """ pend_io(t=1.0)
    This routine will wait (***up to time t, but possibly less***) for
    channel access io to process.
    """
    return _epics.pend_io(t)

def pend_event(t=1.e-5):
    """pend_event(t=1.e-5).
    This routine will wait (***for time t***) for
    channel access events to process.
    """
    return _epics.pend_event(t)

# pvCache is used for storage of pvs in caget/caput so that
#          repeated accesss uses the cached pvs

PVcache = {}
def connect_all():
    """connect to all unconnected PVs
    """
    for pv in PVcache.values():
        try:
            if not pv.connected: pv.connect()
        except:
            pass

def disconnect_all():
    """disconnect from all cached PVs"""
    for pv in PVcache.values():
        try:
            pv.disconnect()
        except:
            pass
        
    
def cleanup():
    """cleanup PVs in cache, run _epics.cleanup:
    This is meant to be call on exiting python session!
    """
    disconnect_all()

def _cache(pvname,use_control=False):
    "manage PVcache -- local storage of pvs for caget/caput"
    p = None
    if PVcache.has_key((pvname,True)):  return PVcache[(pvname,True)]
    if PVcache.has_key((pvname,False)): return PVcache[(pvname,False)]

    p = PV(pvname,connect=True,connect_time=2.0,use_control=use_control)
    PVcache[(pvname,use_control)] = p
    poll()
    return p


def show_pvcache():
    "list known pvs (ie, those in PVcache)"
    for pvkey,pv in PVcache.items():
        print pvkey[0], pvkey[1], pv

def show_pvs():
    _epics.show_pvtable()

def caput(pvname, value, wait=False, timeout=60):
    """caput(pvname, value, wait=False, timeout=60)
    simple put to a pv's value.
       >>> caput('xx.VAL',3.0)

    to wait for pv to complete processing, use 'wait=True':
       >>> caput('xx.VAL',3.0,wait=True)
    """ 
    pv = _cache(pvname)
    return pv.put(value,wait=wait,timeout=timeout)

def caget(pvname, use_char=False):
    """caget(pvname, use_char=False)
    simple get of a pv's value..
       >>> x = caget('xx.VAL')

    to get the character string representation (formatted double, enum string, etc):
       >>> x = caget('xx.VAL', use_char=True)
    """
    pv = _cache(pvname)
    if use_char: return pv.char_value
    return pv.value    

def cainfo(pvname,noprint=False):
    """cainfo(pvname,noprint=False)

    print information about pv
       >>>cainfo('xx.VAL')

    will print out a status report for the pv.  If True, the optional  'noprint' flag
    will NOT print the status report, but return the paragraph as a string.
    """
    pv = _cache(pvname)
    if noprint: return pv.info
    print pv.info
    return None

class PV:
    """== pv: The Process Variable
    
    A pv encapsulates an Epics Process Variable (aka a 'channel').
   
    The primary interface methods for a pv are to get() and put() its value:
      >>>p = PV(pv_name)    # create a pv object given a pv name
      >>>p.get()            # get pv value
      >>>p.put(val)         # set pv to specified value. 

    Additional important attributes include:
      >>>p.pvname           # name of pv
      >>>p.value            # pv value (can be set or get)
      >>>p.char_value       # string representation of pv value
      >>>p.count            # number of elements in array pvs
      >>>p.type             # EPICS data type: 'string','double','enum','long',....

    A pv uses Channel Access monitors to improve efficiency and minimize
    network traffic, so that calls to get() fetches the cached value,
    which is automatically updated. 

    Note that it is important to periodically call poll() or pend_event()
    to make sure that the pv values are up to date.
    
== Initialization, Connection, time-outs:

   On creating a pv [pv = EpicsCA.PV()], the following optional arguments can be given:
       pvname            name of pv                                          [None]
       callback          user-specified callback function (see below)        [None]
       connect           indicate whether or not to connect                  [False]
       use_numpy         use numpy arrays for array data                     [True]
       use_control       use full Control Epics Data Type                    [False]
       connect_time      maximum time (in sec) for connection                [1.0]
       use_char_changes  run user-defined callbacks only when the
                        'char_value' changes, ignoring trivial changes       [True]

   A PV can be created without a pvname and assigned a pvname later.

   In order to communicate with the corresponding channel on the IOC, a PV needs to
   "connect".  This creates a dedicated connection to the IOC on which the PV lives,
   and creates resources for the PV.   A Python PV object cannot actually do anything
   to the PV on the IOC until it is connected.

   Connection is a two-step process.  First a local PV is "created" in local memory.
   This happens very quickly, and happens automatically when a PV is initialized (and
   has a pvname).

   Second, connection is completed with network communication to the IOC.  This is
   necessary to determine the PV "type" (that is, integer, double, string, enum, etc)
   and "count" (that is, whether it holds an array of values) that are needed to
   allocate resources on the client machine.  Again, this connection must happen before
   you can do anything useful with the PV.

   When done as a single step, the creation and connection process takes 30msec.  This
   is a feature of Channel Access.   In normal use this is fast enough, but for cases
   where you know that you're going to use many PVs, this connection time can add up.
   In this case, it turns out (again, a Channel Access feature) that it is much faster
   to create many PVs without connecting to them, and then connect to all of them.
   
   Because of this, a Python PV is created with "connect=False" by default.  This
   delays complete connection until it is needed.  That is, doing a .get() or .put()
   will automatically connect to the PV.  Generally this is good, as it reduces
   average connection time, but there is an important caveat:
      an unconnected PV will not respond to changes.

   That means, you cannot create a bunch of PVs with  x = PV(pvname) and then
   poll() for changes -- you won't see any changes until the PVs are connected.
   

   A convienent way to deal with this is to run EpicsCA.connect_all() prior to polling
   for changes.  This function will complet the connection of all unconnected PVs.
            
   The 'connected' attribute reflects wether the pv is successfully connected.

   >>> p = PV()
   >>> p.connected
   False
   >>> p
   <pv: unnamed>

   >>> p.pvname = 'XXX:m1.VAL'
   >>> p.connected
   True

   >>> p
   <pv: 'XXX:m1.VAL', count=1, type=double, access=read/write>

   If a pv cannot connect in the connect_time, an EpicsCAError will be raised.
   
== Information about a pv

   In addition to 'value', 'char_value', and 'connected' discussed above, a pv has the
   following attributes:
       count         element count: 1 for scalars, number of array elements for arrays.
       precision     precision (number of values past decimal point) for floating point values
       
       host          name of host providing pv
       access        string describing read/write access
       ctype         integer containing EPICS type (int, long, enum, etc)
       type          string describing EPICS type
       enum_strings  list of strings for Enumeration States for enum variables

       status        integer status  (1 means OK, apparantly)
       severity      EPICS severity  (0 means OK, apparantly)

       info          text paragraph of 'status report' listing most of all attributes.

   The following additional 'Control Type' information can also be obtained for pvs:
       units         string containing units, if applicable (else None)
       hlim          control high limit
       llim          control low limit
       display_llim  display high limit
       display_hlim  display low limit
   To get this information, you must create the PV with the optional 'use_control=True'
   argument to PV():

   >>> p = PV('XXX:m1.VAL', use_control=True)
   >>> print p.units
   'mm'

   PV representation:
       
       At the python command prompt, typing the name of the PV object will print a short
   description of the PVs connection status and type.  Some examples:
   >>> p = EpicsCA.PV()
   >>> p
   <PV: unnamed>
   >>> p = EpicsCA.PV('xxx',connect=False)
   >>> p, p.connected
   (<PV: 'xxx': unconnected>, False)
   >>> p.get()
   >>> p, p.connected
   (<PV: 'xxx', count=1, type=double, access=read/write>, False)

 
== PV Values, String representations

   The 'value' attribute holds the PVs value and can be gotten or set either with .get()/.set()
   methods or simply by accessing/assigning to the 'value':

   >>> print p.value
   1.000
   >>> p.value = 2.0     # (PV processes, motor moves, etc)

   Or, with methods:
   
   >>> print p.get()
   2.000
   >>> p.put(1.0)

   The 'char_value' attribute holds a string representation of the value.  For floating point
   numbers and integers, this is simply an appropriately formatted string (using the precision).
   For ENUM variables, this contains the 'enum string' name.

   The char_value attribute cannot be set.

== Getting and Putting PVs

   get() can retrieve either the 'raw' value or a string representation -- the 'char_value'.
   That is,  pv.get() and pv.value will return the 'raw' value, which may be of several data
   types (int, float, array, string).

   To get the string representation for a PV, use pv.get(use_char=True) or pv.char_value.
   What the 'char_value' holds depends on the data type, but it will always be a python string.
   For string PV data, the char_value is the same as the raw value. For integers, it is
   pretty straightforward.  For floats/doubles, the char_value is formatted according to the
   PVs precision.  For enum PVs, the char_value hold the value description.  For arrays, the
   char_value will be '<array(size=N, type=I)>' where N is the length of the array, and the
   type will tell the data type of each array member.

   With put(), you simply provide the value (the raw value, not the char_value) that you want
   to set the value to.  These are equivalent.
   >>> p.put(1.0)
   >>> p.value = 1.0


   It is often desireable to know when the put has completes (eg, when a motor is done 
   moving, when a counter is done counting, or in general when a record is fully processed).
   There are two ways to do this:

   First, you can use the the 'wait=True' option in put():
   
   >>> put(1.0, wait=True, timeout=60.0)
   
   This will block until the put is complete or until the timeout (in seconds, and which has a
   default value of 3600.0) has expired.  When using python from the command-line, you can use
   'Control-C' to break out of this blocking put().  
   
   An alternative is to not block, but to poll in python, waiting for the p.put_complete
   attribute to be True.

   >>> p.put(1.0)
   >>> while not p.put_complete:
   >>>     pend_event()
   >>>     print 'still moving'
   
   This approach can be a bit more convenient for interactive codes.
   
      

== User Callbacks (monitors):

  Under normal operation of a program communicating with Epics, pend_event(), poll(), or
  pend_io() should be called periodically.
  
  When a PVs value on the host machine has changed, a pend_event() or poll() is the only way
  for the local application to know that the change has occurred.  When a variable changes
  and one of the polling routines is called, the internal value and attributes are
  automatically updated to the latest values.

  In addition, you can define one or more 'callback' routines to be run every time a PVs state
  is seen to change.  The callback routine(s) can be used to update GUI widgets, for example.
   
  A callback can be specified at PV creation:
  >>>def my_callback(PV=None, **kws):
         print 'my callback ', PV.pvname, PV.value

  >>>p = EpicsCA.PV('XXX', callback=my_callback)
  
  See the closure class (in this module) for a convenient way to set a callback with arguments
  and keywords.

  **********  Important Note: **********
     callback functions will be called with the first argument 'PV' holding the
     PV object.

     You *must* have a 'PV' argument in your callback routine!!
  **********  Important Note: **********
  
  Additional callbacks can be added and removed at any time.  To do this, a dictionary of
  callbacks is maintained, each having an 'index' as a key.  If not specified, an index key
  will be created.  

  add_callback(self,callback=None,index=None,*args,**kws):
     set a user defined callback, returns  the index key for this callback.

  remove_callback(index=None):
      remove a callback given its index name

  clear_callbacks():
      clear all user-defined callbacks

  list_callbacks():
      returns a list of existing callbacks and their indices
      
  set_callback(callback=None,*args,**kws):
      set a callback, erasing all current callbacks.  This is included for backward
      compatibility -- normally, add_callback() should be used.

"""   

    MAX_STRING_LEN = 40
    _TypeMap = {_epics.DBR_STRING:("cArray",'string',str),
                _epics.DBR_CHAR:  ("cArray",'char',str),
                _epics.DBR_ENUM:  ("sArray",'enum',int),
                _epics.DBR_INT:   ("iArray",'int',int),
                _epics.DBR_SHORT: ("sArray",'short',int),               
                _epics.DBR_LONG:  ("lArray",'long',long),
                _epics.DBR_FLOAT: ("fArray",'float',float),
                _epics.DBR_DOUBLE:("dArray",'double',float),
                -1:               ("iArray",'int',int) }    

    connect_ErrorMsg   = "cannot connect to %s -- may need a connection timeout longer than %f seconds"
    enumrange_ErrorMsg = "value %i out of range for enum PV %s"
    callback_ErrorMsg  = "severe error with get callback for %s"
    setattr_ErrorMsg   = "cannot set %s for %s"
    
    repr_Normal        = "<PV: '%s', count=%i, type=%s, access=%s>"
    repr_unnamed       = "<PV: unnamed>"
    repr_unconnected   = "<PV '%s': unconnectd>" 
    
    def __init__(self,pvname=None,   callback=None,      connect=False, connect_time=1.0,
                 use_numpy=True,     use_control=False,  use_char_changes=True):

        self.__in_INIT = True
        self.use_numpy  = use_numpy
        self.pvname     = pvname
        self._connected = False
        self._val       = None
        self._cval      = None
        self._status    = None
        self._count     = None
        self._llim      = None
        self._hlim      = None
        self._units     = None
        self._severity  = None
        self._precision = None
        self._disp_llim = None
        self._disp_hlim = None
        self._enumstrs  = None
        self._chid      = None
        self._ctype     = -1
        self._isControl = use_control
        self.use_char_changes =  use_char_changes
        self.callbacks = {}

        self.__in_INIT = False
        if callback is not None:    self.set_callback(callback)

        if self.pvname is None: return
        
        if PVcache.has_key((self.pvname,self._isControl)):
            self = PVcache[(self.pvname,self._isControl)]
        else:
            self._chid = _epics.create_pv(self.pvname)
            PVcache[(self.pvname,self._isControl)] = self
            pend_event(1.e-5)

            if connect:   self.connect(connect_time=connect_time)
        
    def connect(self,force=False,connect_time=1):
        """connect a pv to the epics layer, or reconnect:"""
        if self.pvname is None: return False
        if type(self.pvname) != types.StringType: return False
        self.pvname.strip()
        if len(self.pvname) < 1: return False
        t0 = time.time()

        if self._connected:
            if force:
                self._connected = False
                self._chid = _epics.create_pv(self.pvname)            
            else:
                return True
        elif self.pvname is not None and self._chid is None:
            self._chid = _epics.create_pv(self.pvname)

        pend_event(1.e-5)
        while (not self._connected and (time.time()-t0 <= connect_time)):
            ctype = _epics.field_type(self._chid)
            count = _epics.element_count(self._chid)
            pend_event(1.e-3)
            stat = pend_io(1.e-3)
            self._connected = (_epics.ECA_NORMAL == stat and count > 0 and ctype > -1)

        if not self._connected: return False
        # print 'PV connected ', self.pvname
        self.connect_time = time.time() - t0
        self._ctype  = ctype
        self._host   = _epics.host_name(self._chid)
        pend_io(0.1)
        rwacc        = _epics.read_access(self._chid) + 2*_epics.write_access(self._chid)
        self._access =  ('no access','read-only','write-only','read/write')[rwacc]

        self._count = count
        if self._ctype in (_epics.DBR_STRING, _epics.DBR_CHAR):
            count = max(40,count)+1

        # SWIG pointers for putting values
        self._ptr   = getattr(_epics,"new_%s"     % self._TypeMap[ctype][0])(count)
        self._pset  = getattr(_epics,"%s_setitem" % self._TypeMap[ctype][0])

        # look up additional type-dependent information
        if self._ctype == _epics.DBR_ENUM:
            self.get_enum_strings()
        elif self._ctype in ( _epics.DBR_FLOAT,_epics.DBR_DOUBLE):
            self._precision = _epics.get_precision(self._chid)

        # for control types, all "extra fields" are automatically included.
        # for the "simple" types, get precision/enum_strings here
        reqtype = 0
        if self._isControl:   reqtype = 1


        # set C level callback to internal method
        _epics.register_getcallback(self._chid, reqtype, self.__get_callback)
        pend_io(1.0)
        if self._connected:  PVcache[(self.pvname,self._isControl)] = self

        return self._connected
                
    def poll(self):
        """check for connection, then pend_event: this is where the real action happens!"""
        if not self._connected: self.connect()
        pend_event(1.e-5)

    def put(self,value,wait=False,timeout=3600.0):
        """put value, optionally waiting until the put is complete:
           put(value, wait=True, timeout=3600.0)
           
         timeout is a time out in seconds: if the put() has not completed in
         that time, put() will return anyway. The time is approximate, typically
         0.01 to 0.1 longer than specified, and should not be used as a timer.
        """
        self.poll()
        if value is None: return None
        import signal
        cast = self._TypeMap[self._ctype][2]
        if self._ctype in (_epics.DBR_STRING, _epics.DBR_CHAR):
            if self._ctype == _epics.DBR_CHAR and self._count == 1:
                value = chr(int(value))
            else:
                strlen = self._count
                if self._ctype == _epics.DBR_STRING: strlen = min(self.MAX_STRING_LEN-1,len(value))
                value = cast(value) + '\x00'*(strlen)
            _epics.memmove(self._ptr,value)   # SWIGs memmove!!!
        elif self._count == 1:
            if self._ctype == _epics.DBR_ENUM:
                v = cast(value)
                if max(0,min(v,len(self._enumstrs)-1)) != v:
                    raise EpicsCAError, self.enumrange_ErrorMsg  % (v,self.pvname)

            self._pset(self._ptr,0,cast(value))
            
        elif self._count > 1:
            # may need to convert data from numpy array to list
            if not isinstance(value,list): value = list(value)
            for i in range(min(len(value), self._count)):
                self._pset(self._ptr, i , cast(value[i]))

        iwait = 0
        if wait: iwait = 1
        # save current signal handler, as we'll need to restore it
        # since  _epics.put() overrides Ctrl-C 
        sigint_handler = signal.getsignal(signal.SIGINT)

        try:
            stat = _epics.put(self._ctype,self._count, self._chid,self._ptr,iwait,timeout)
        except TypeError:
            print 'EpicsCA.PV error on put for PV = %s' %  self.pvname
            print '  ctype: ', self._ctype, type(self._ctype)
            print '  count: ', self._count, type(self._count)
            print '  chid : ', self._chid,  type(self._chid)
            print '  ptr  : ', self._ptr,   type(self._ptr)
            print '  iwait: ', iwait,  timeout
            print ' Please report this problem!!'
            stat = None
            
        signal.signal(signal.SIGINT,sigint_handler)            
        pend_io(0.1)
        pend_event(1.e-5)
        return stat

    def __put_done(self):
        "returns True when a put has completed"
        return (0 == _epics.get_put_status(self._chid))
    
    def get(self,use_char=False):
        """ get(): returns a pvs value.
        equivalent to accessing the 'value' attribute.
        See also get_string() to  get the string representation.

        Note that this relies on the 'get callback [see _get_callback() below]
        to keep the latest values.
        """
        self.poll()
        if use_char: return self._cval
        return self._val

    def get_enum_strings(self):
        "return list of enumeration strings (can also access .enum_strings attribute)"
        self.poll()
        if (self._ctype == _epics.DBR_ENUM) and (self._enumstrs is None):
            pnum = _epics.new_iPnt()
            pstr = _epics.new_cArray(32)
            _epics.iPnt_assign(pnum, 32)
            s = _epics.get_enum_strings(self._chid,pnum, pstr)
            if (s == 0):
                nvals = _epics.iPnt_value(pnum)
                self._enumstrs = [_epics.cArray_getitem(pstr,i) for i in range(nvals)]
            _epics.free_enum_strings(nvals, pstr)
            _epics.delete_cArray(pstr)
            _epics.delete_iPnt(pnum)
        return self._enumstrs

    def get_info(self):
        """ return list of strings containing an information paragraph about pv"""
        self.poll()
        out = []
        out.append("== %s" % self.pvname)

        # list basic attributes
        vtype = self._TypeMap[self._ctype][1]

        if self._count==1:
            if vtype in  ('int','short','long','enum'):
                out.append('   value        = %i' % self._val)
            elif vtype in ('float','double'):
                out.append('   value        = %g' % self._val)
            elif vtype in ('string','char'):
                out.append('   value        = %s' % self._val)
        else:
            aval,ext,fmt = [],'',"%i,"
            if self._count>5: ext = '...'
            if vtype in  ('float','double'): fmt = "%g,"
            for i in range(min(5,self._count)):
                aval.append(fmt % self._val[i])
            out.append("   value        = array  [%s%s]" % ("".join(aval),ext))

        for i in ('char_value','count','type','units','precision','host','access',
                  'status','severity', 'hlim','llim','display_hlim','display_llim'):
            att = getattr(self,i)
            if att is not None:
                out.append('   %.13s= %s' % (i+' '*16, str(att)))

        # list enum strings
        if vtype == 'enum':
            out.append('   enum strings: ')
            for i,s in enumerate(self._enumstrs): out.append("        %i=%s " % (i,s))

        # list callbacks
        cbs = self.list_callbacks()
        if len(cbs) > 0:
            out.append("  user-defined callbacks:")
            for i in cbs:  out.append('      %s=%s' % (str(i[0]),i[1]))
        else:
            out.append("  no user callbacks defined.")
        out.append('==')
        return '\n'.join(out)

    def remove_callback(self,index=None):
        "remove a callback given its index name"
        for i in self.callbacks.keys():
            if index == i: self.callbacks.pop(i)

    def clear_callbacks(self):
        "clear all user-defined callbacks"
        self.callbacks = {}

    def list_callbacks(self):
        "return list of existing callbacks"
        out =  []
        names = self.callbacks.keys()
        names.sort()
        for n in names:
            cb = self.callbacks[n]
            if isinstance(cb,closure):
                out.append((n,cb.func.func_name))
        return out
    
    def set_callback(self,callback=None,*args,**kws):
        " set a callback (for backward compatibility -- use 'add_callback')"
        self.callbacks = {}
        return self.add_callback(callback,*args,**kws)
    
    def add_callback(self,callback=None,index=None,*args,**kws):
        """ set a user defined callback"""
        if kws.has_key('pv'):
            print "Warning:  callback argument 'pv' will be overwritten"
        kws.update({'pv':self})
        if index == None:
            index = len(self.callbacks) + 1
            while index in self.callbacks.keys(): index = index + 1
        if callback:  self.callbacks[index]= closure(callback,*args,**kws)
        return index       

    def __get_callback(self, pvname=None, value=None, count=1, units=None,
                       status=None, precision=None, enumstrs=None, severity=0,
                       llim=None, hlim=None, disp_lo=None, disp_hi=None,*args,**kws):
        """  ***** DO NOT CALL THIS ROUTINE DIRECTLY!! *****
        This is used as the C-level 'callback', and is automatically called
        when the value of the pv changes and when _epics.pend_event() is
        run, as from pend_event() or poll().

        You can assign additional callback(s) (with self.add_callback),
        that will be run from this routine.
        """
        if pvname != self.pvname:
            raise EpicsCAError, self.callback_ErrorMsg % self.pvname

        if self._host is None:
            self._host   = _epics.host_name(self._chid)
            pend_io(0.1)
        if self._access is None:
            rwacc        = _epics.read_access(self._chid) + 2*_epics.write_access(self._chid)
            self._access =  ('no access','read-only','write-only','read/write')[rwacc]
            pend_io(0.1)

        old_cval     = self._cval
        self._val    = value
        self._status = status
        self._count  = count
        self._units  = units
        self._llim   = llim
        self._hlim   = hlim
        self._severity  = severity
        self._disp_llim = disp_lo
        self._disp_hlim = disp_hi
        if precision is not None: self._precision = precision
        if enumstrs is not None:  self._enumstrs = enumstrs

        # convert array value to numpy array 
        if (HAS_NUMPY and (count > 1) and self.use_numpy and 
            (self._ctype in (_epics.DBR_FLOAT,_epics.DBR_DOUBLE,
                             _epics.DBR_LONG,_epics.DBR_SHORT))):
            self._val = numpy.array(self._val)

        if self._count > 1:
            # convert CHAR array to string
            if self._ctype == _epics.DBR_CHAR:
                stmp = ''.join([chr(i) for i in self._val])
                slen = stmp.find("\x00")
                if slen==-1: slen = len(stmp)
                self._val  = stmp[:slen].rstrip()
                self._cval = self._val                
            else:
                self._cval = "<array size=%d, type=%s>" % (len(self._val),
                                                           self._TypeMap[self._ctype][1])
        
        elif self._ctype == _epics.DBR_ENUM:
            self._cval = 'illegal value'
            if self._val >= 0 and self._val < len(self._enumstrs):
                self._cval = self._enumstrs[self._val]
        elif self._ctype in (_epics.DBR_DOUBLE, _epics.DBR_FLOAT):
            frmt  = "%%.%if"
            if 4 < abs(int(math.log10(abs(self._val + 1.e-9)))): frmt = "%%.%ig"
            self._cval = (frmt % self._precision) % self._val
        else:
            self._cval = "%s" % self._val
            
        # here we detect trivial changes (use_char_changes)
        if not (self.use_char_changes and (old_cval==self._val) and
                (self._ctype == _epics.DBR_CHAR or self._count > 1)):
            
            for index,user_callback in self.callbacks.items():
                if (index is not None and callable(user_callback)):  user_callback()
            
        return None

    def __repr__(self):
        if self.pvname is None:     return self.repr_unnamed
        if not self._connected:     return self.repr_unconnected % self.pvname
        return self.repr_Normal % (self.pvname, self._count,
                                   self._TypeMap[self._ctype][1],self.access)
    
    def __str__(self):              return self.__repr__()
    def __eq__(self,other):
        try:
            return ( (self.pvname == other.pvname) and
                     (self._chid  == other._chid)  and
                     (self._host  == other._host))
        except:
            return False
        
    def __copy__(self):             return self
    def __deepcopy__(self,visit):   return self
    def __ne__(self,other):         return not (self.__eq__(other))
    def __ge__(self,other):         return self.__eq__(other)
    def __le__(self,other):         return self.__eq__(other)
    def __gt__(self,other):         return False
    def __lt__(self,other):         return False
    def __nonzero__(self):          return self._connected
       
    def __getattr__(self,attr):
        """internal getting of attributes.
        For many 'shadowed' values (those that should not be set),
        this just retrieves the shadowed value.

        When getting 'value' or 'char_value' here, a real get() is done.        
        """
        if (attr in ('value','char_value')):
            self.get()
            if (attr == 'value'):           return self._val
            if (attr == 'char_value'):      return self._cval
        elif (attr == 'status'):            return self._status
        elif (attr == 'put_complete'):      return self.__put_done()
        elif (attr == 'count'):             return self._count
        elif (attr == 'units'):             return self._units
        elif (attr == 'hlim'):              return self._hlim
        elif (attr == 'llim'):              return self._llim
        elif (attr == 'display_hlim'):      return self._disp_hlim
        elif (attr == 'display_llim'):      return self._disp_llim
        elif (attr == 'enum_strings'):      return self._enumstrs
        elif (attr == 'severity'):          return self._severity
        elif (attr == 'precision'):         return self._precision
        elif (attr == 'connected'):         return self._connected
        elif (attr == 'ctype'):             return self._ctype
        elif (attr == 'chid'):              return self._chid.__hex__()
        elif (attr == 'host'):              return self._host
        elif (attr == 'access'):            return self._access
        elif (attr == 'info'):              return self.get_info()
        elif (attr == 'type'):              return self._TypeMap[self._ctype][1]
        elif (self.__dict__.has_key(attr)): return self.__dict__[attr]
        
    def __setattr__(self,attr,val):
        """internal setting of attributes.
        Note that many attributes should not be set, and trying to set them will
        raise an exception.

        Important exceptions:
            setting a pvs 'value' will do a 'put()' for that value, really
            setting the Epics Value.

            setting a pvs 'pvname' will reconnect to the (possibly new) pv.
        """
        if (attr in ('char_value','status','count','units','hlim','llim',
                     'enum_strings','precision','severity','connected','ctype',
                     'display_llim','display_hlim','host','access','chid')):
            raise EpicsCAError, self.setattr_ErrorMsg  % (attr,self.pvname)

        self.__dict__[attr] = val
        if (attr == 'value'  and self.connected):     return self.put(val)
        if (attr == 'pvname' and not self.__in_INIT): return self.connect()

    def disconnect(self):
        try:
            if PVcache.has_key((self.pvname,self._isControl)):
                PVcache.pop((self.pvname,self._isControl))
            if self._chid is not None:
                _epics.destroy_pv(self._chid)
                self._chid = 0
                self._connected = False
                self.callbacks = {}
                if (self._ptr is not None):
                    killer = getattr(_epics,"delete_%s"  % self._TypeMap[self._ctype][0])
                    killer(self._ptr)
                pend_event(1.e-5)
                pend_io(0.01)
        except TypeError:
            pass
        except:
            print 'error on disconnect!'
        return self._connected
    
if __name__ == '__main__':
    print 'see the test/ directory for tests.'
