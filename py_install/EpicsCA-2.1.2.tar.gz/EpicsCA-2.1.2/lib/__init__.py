"""
   EpicsCA python module
   Matthew Newville <newville@cars.uchicago.edu>
   CARS, University of Chicago

   version    :  2.1.2 (svn revision 110)
   last update:  29-Oct-2007
         
== Overview:
   This module provides an interface to Epics Channel Access.

   The main interface to Epics in this module is the pv object,
   which holds an Epics Process Variable (aka a 'channel').

   Here's a simple example of using a pv:
      >>>from EpicsCA import pv     # import the pv class
      >>>pv = pv('XXX:m1.VAL')      # connect to a pv with its name.

      >>>print pv.value             # get the current value of the pv.
      >>>pv.value = 3.0             # set the pv's value.

      >>>print pv.get()             # gets the current value.
      >>>pv.put(3.0)                # set the pv's value.

   beyond getting and setting a pv's value, a pv includes  these features: 
      1. string representation of pv values.
      2. methods for information about the pv and its channel access
         connection, such as host name, units, precision, control and
         display limits, names of enumeration states, etc.
      3. support for user-defined "callbacks": python functions that
         are called automatically when the process variable changes.
      4. the put() method can optionally wait for processing to complete
         (for a motor to finish moving, for example).

   See the documentation for the pv class for a more complete description.
   
   This module also contains simple caget(), caput(), and cainfo() functions
   for procedural use of Epics.

== caget() / caput() / cainfo()

   caget(pvname,use_char=False)
       returns value of a named pv.  With use_char=True, it returns the string
       representation (eg, a formatted double or enum string).

   caput(pvname, value, wait=False,timeout=3600)
       sets the value of a named pv.  With wait=True, the function will wait until
       put is "complete" (motor done moving, all records processed, etc) or until
       the timeout has expired.  An alternative is to put without wait=True, and
       poll in python for the PVs put_complete attribute to become True.

   cainfo(pvname, noprint=False)
       prints (or optionally returns) a paragraph describing the pv attributes
       (value, count, type, units, precision, host, read/write access, control and
       display limits, severity, status, names of user-defined callback functions,
       and names of enumeration states).  With noprint=True, the info paragraph will
       not be printed, but be returned.      
       
   Internally, the EpicsCA module uses a simple cache of pvs so that caput()/caget()
   on the same pv does not need to reconnect to the pv.

   show_pvcache()
       shows the list of cached pvs.
   
== poll() / pend_io() / pend_event()

   For Epics Channel Access to work smoothly, it is important for Epics events and
   input/output to be proessed.  To do this, one of pend_io() or pend_event() must be
   call periodically in the code interacting with Epics.

   pend_event(t=1.e-5)
       will wait for time t for all events to be processed.  That is, it will hang
       for time t.  
   pend_io(t=1.0)
       will wait for up to time t for all i/o to be processed.

   poll() = pend_event(t=1.e-5)

   Calling these polling functions may cause code to be executed for each pv that
   has changed since the last time a polling function was called.  If user-supplied
   callbacks have been defined, these will be run for the changed pvs.  Because of
   this, it is possible for the polling functions to take a while to run.

   In any long running Epics application, an event loop should be set up and one
   of the polling functions should be called at reasonable intervals to be able to
   see updated values of pvs.
   
== implementation, code layout
   
   EpicsCA/PV.py is the principle class and source code file for EpicsCA
   EpicsCA/__init__.py imports most of its exposed objects from PV, including
   the PV class itself, as well as caget, caput, cainfo, poll, pend_event,
   and pend_io.

   Motor.py and other additional class files import PV directly.

   wx/ and wxlib.py there use PV and pend_* functionality as well.
   
== miscellaneous

   closure class:
       A simple way to create a callback function with arguments.
       >>>def my_action(x=None):  print '     my action: x = ', x
       >>>c = closure(my_action,x=1)
       >>>c()
            my action: x = 1
       >>>c(x=2)
            my action: x = 2       
"""
__version__ = '2.1.2'

import _epics
from PV import PV, caget, caput, cainfo
from PV import poll, pend_io, pend_event, connect_all, disconnect_all
from PV import PVcache, EpicsCAError, HAS_NUMPY
from PV import show_pvcache
from Motor import Motor
from alarm import alarm
