#!/usr/bin/env python
from PV import PV, pend_event
import time
import types
   
class alarm:
    """ alarm class for a PV:
    run a user-supplied callback when a PV's value goes out of an acceptable range

    quick synopsis:
       The supplied _callback_ will be run when a _comparison_ of the pv's value
       and a _trip point_ is True.  An optional _alert delay_ can be set to limit
       how frequently the callback is run

    arguments:
       pvname             name of PV for which to set alarm
       trip_point         value of trip point
       comparison         a string for the comparison operation: one of
                              'eq', 'ne', 'le', 'lt', 'ge', 'gt'
                              '==', '!=', '<=', '<' , '>=', '>'
       callback           function to run when the comparison(value,trip_point) is True
       alert_delay        time (in seconds) to stay quiet after executing a callback.
                          this is a _minimum_ time, as it is checked only when a PVs value
                          actually changes.  See note below.
       notify_all_alarms  whether to call alarm callback even for "Alarm to Alarm"
                          transitions: where the pv was in an alarm state and changed value
                          to another alarm state.
                          This is normally False, so that the alarm callback is called only
                          when going from "No Alarm" to "Alarm" status.

       
    example:
       >>> from EpicsCA import alarm, pend_event
       >>> def alarmHandler(pv=None,**kw):
       >>>     print 'Alarm!! ', pv.pvname, pv.value
       >>> alarm(pvname = 'XX.VAL',
       >>>       comparison='gt',
       >>>       callback = alarmHandler,
       >>>       trip_point=2.0,
       >>>       alert_delay=600)
       >>> while True:
       >>>     pend_event()

    when 'XX.VAL' exceeds (is 'gt') 2.0, the alarmHandler will be called.
   
    
    notes:
      alarm_delay:  The alarm delay avoids annoying over-notification by specifying a
                    time to NOT send messages, even when a PV value is changing and
                    out-of-range.  Since Epics callback are used to process events,
                    the alarm state will only be checked when a PV's value changes.
      notify_all_alarms  This sets whether to notify on "Alarm to Alarm" transitions
                    this is normally false, so that notifications only happen on
                    transitions from No Alarm to Alarm.
                    
                    With "notify_all_alarms" True, the user callback is run when:
                       The PV value has changed.
                       The PV value is 'out-of-range' [ comparison(value,trip_point) is True]
                       It has been at least alarm_delay seconds since the callback was run.

                    With "notify_all_alarms" False (the default), the user callback is run when:
                       The PV value has changed.
                       The PV value was 'in-range' [ comparison(value,trip_point) is False]
                       The PV value is 'out-of-range' [ comparison(value,trip_point) is True]
                       It has been at least alarm_delay seconds since the callback was run.                    


      callback function:  the user-supplied callback function should have the following
                    keyword argument (using **kw is always recommended!):

                    pv          will hold the EpicsCA pv object for the pv
                    comparison  will hold the comparison used to define 'out of range'
                    trip_point  will hold the trip point used to define 'out of range'
    
    """
    valid_comparisons = {'eq':'__eq__', '==':'__eq__',
                         'ne':'__ne__', '!=':'__ne__',
                         'le':'__le__', '<=':'__le__',
                         'lt':'__lt__', '<' :'__lt__',
                         'ge':'__ge__', '>=':'__ge__',
                         'gt':'__gt__', '>' :'__gt__' }
    def __init__(self, pvname=None, trip_point=None, comparison=None, callback=None,
                 notify_all_alarms=False,
                 alert_delay=0, **kw):

        self.pv = PV(pvname, use_char_changes=False,connect_time=3)
        self.trip_point  = trip_point
        self.last_alert  = 0
        self.alert_delay = alert_delay
        self.notify_all_alarms = notify_all_alarms
        self.callback    = callback or self.__default_callback
        if self.pv is None: return

        comparison  = comparison.replace('_','')
        self.__comp = self.valid_comparisons.get(comparison,None)
        self.alarm_state = False
        try:
            self.alarm_state =  getattr(self.pv.get(),self.__comp)(self.trip_point)
        except:
            pass

        self.pv.add_callback(self.__check_alarm)
        
    def __check_alarm(self,pv=None,**kw):
        if pv is None or self.__comp is None or self.trip_point is None: return
        
        val = self.pv.get()
        if type(val) == types.IntType: val = float(val)
        old_alarm_state  = self.alarm_state
        self.alarm_state =  getattr(val,self.__comp)(self.trip_point)

        now = time.time()
        notify = self.alarm_state and ((now - self.last_alert) > self.alert_delay) 

        # normally we only notify on transitions from no_alarm to alarm:
        if not self.notify_all_alarms:
            notify = notify and (not old_alarm_state)

        if notify:
            self.last_alert = now
            self.callback(pv=self.pv, comparison=self.__comp, trip_point=self.trip_point)
          
    def __default_callback(self,pv=None,comparison=None, trip_point=None, **kw):
        print 'pv alarm: ', pv.pvname , pv.char_value, time.ctime()


if __name__ == '__main__':
    def alarmHandler(pv=None,comparison='',trip_point=None,**kw):
        print 'An alarm:: ', pv.pvname, pv.char_value, comparison, trip_point, time.ctime()
        
    x = alarm(pvname = '13BMA:DMM1Ch3_raw.VAL',     callback = alarmHandler, 
              comparison='gt',   trip_point=26.8,   alert_delay=5)

    for i in range(600):  pend_event(0.1)
    
        
