#!/usr/bin/python
# This module provides support for the EPICS motor record.
# 
# Author:         Mark Rivers / Matt Newville
# Created:        Sept. 16, 2002
# Modifications:
#   Aug 19, 2004  MN
#                 1. improved setting / checking of monitors on motor attributes
#                 2. add 'RTYP' and 'DTYP' to motor parameters.
#                 3. make sure the motor is a motor object, else raise a MotorException.

#   May 11, 2003  MN
#                 1. added get_pv(attribute) to return PV for attribute
#                 2. added __check_attr_stored(attr) method to
#                    consolidate checking if a PV is currently stored.
#   Feb 27, 2003  M Newville altered EpicsMotor:
#                 1. uses the EpicsCA.PV class, which automatically
#                    uses monitors to efficiently determine when to
#                    get PV values from the IOC
#                 2. increase the number of Motor attributes.
#                 3. increase the number of 'virtual attributes'.
#                    For example,
#                      >>>m = EpicsMotor('13BMD:m38')
#                      >>>m.drive = 20.
#                    causes the motor to move to 20 (user units).
#

from PV import PV, poll, pend_io, pend_event

class Motor:
    """Epics Motor Class, using EpicsCA, and automatic callbacks

   This module provides a class library for the EPICS motor record.

   It uses the EpicsCA.PV class, and emulates 

   Virtual attributes:
      These attributes do not appear in the dictionary for this class, but
      are implemented with the __getattr__ and __setattr__ methods.  They
      simply get or putthe appropriate motor record fields.  All attributes
      can be both read and written unless otherwise noted. 

      Attribute        Description                  Field
      ---------        -----------------------      -----
      drive            Motor Drive Value            .VAL
      readback         Motor Readback Value         .RBV    (read-only) 
      slew_speed       Slew speed or velocity       .VELO
      base_speed       Base or starting speed       .VBAS
      acceleration     Acceleration time (sec)      .ACCL
      description      Description of motor         .DESC
      resolution       Resolution (units/step)      .MRES
      high_limit       High soft limit (user)       .HLM
      low_limit        Low soft limit (user)        .LLM
      dial_high_limit  High soft limit (dial)       .DHLM
      dial_low_limit   Low soft limit (dial)        .DLLM
      backlash         Backlash distance            .BDST
      offset           Offset from dial to user     .OFF
      done_moving      1=Done, 0=Moving, read-only  .DMOV
 
   Exceptions:
      The check_limits() method raises an "MotorException" if a soft limit
      or hard limit is detected.  The move() and wait() methods call 
      check_limits() before they return, unless they are called with the 
      ignore_limits=1 keyword set.

   Example use:
      from epicsMotor import *
      m=epicsMotor('13BMD:m38')
      m.move(10)               # Move to position 10 in user coordinates
      m.move(100, dial=1)      # Move to position 100 in dial coordinates
      m.move(1, step=1, relative=1) # Move 1 step relative to current position
      m.wait()                 # Wait for motor to stop moving
      m.wait(start=1)          # Wait for motor to start moving
      m.wait(start=1, stop=1)  # Wait for motor to start, then to stop
      m.stop()                 # Stop moving immediately
      high = m.high_limit      # Get the high soft limit in user coordinates
      m.dial_high_limit = 100  # Set the high limit to 100 in dial coodinates
      speed = m.slew_speed     # Get the slew speed
      m.acceleration = 0.1     # Set the acceleration to 0.1 seconds
      p=m.get_position()       # Get the desired motor position in user coordinates
      p=m.get_position(dial=1) # Get the desired motor position in dial coordinates
      p=m.get_position(readback=1) # Get the actual position in user coordinates
      p=m.get_position(readback=1, step=1) Get the actual motor position in steps
      p=m.set_position(100)   # Set the current position to 100 in user coordinates
         # Puts motor in Set mode, writes value, puts back in Use mode.
      p=m.set_position(10000, step=1) # Set the current position to 10000 steps

    """
    # parameter name (short), PV suffix,  longer description

    __motor_params = {
        'acceleration':    ('ACCL', 'acceleration time'),
        'back_accel':      ('BACC', 'backlash acceleration time'),
        'backlash':        ('BDST', 'backlash distance'),
        'back_speed':      ('BVEL', 'backlash speed'),
        'card':            ('CARD', 'Card Number '),
        'dial_high_limit': ('DHLM', 'Dial High Limit '),
        'direction':       ('DIR',  'User Direction '),
        'dial_low_limit':  ('DLLM', 'Dial Low Limit '),
        'settle_time':     ('DLY',  'Readback settle time (s) '),
        'done_moving':     ('DMOV', 'Done moving to value'),
        'dial_readback':   ('DRBV', 'Dial Readback Value'),
        'description':     ('DESC', 'Description'),
        'dial_drive':      ('DVAL', 'Dial Desired Value'),
        'units':           ('EGU',  'Engineering Units '),
        'encoder_step':    ('ERES', 'Encoder Step Size '),
        'freeze_offset':   ('FOFF', 'Offset-Freeze Switch '),
        'move_fraction':   ('FRAC', 'Move Fraction'),
        'hi_severity':     ('HHSV', 'Hihi Severity '),
        'hi_alarm':        ('HIGH', 'High Alarm Limit '),
        'hihi_alarm':      ('HIHI', 'Hihi Alarm Limit '),
        'high_limit':      ('HLM',  'User High Limit  '),
        'high_limit_set':  ('HLS',  'High Limit Switch  '),
        'hw_limit':        ('HLSV', 'HW Lim. Violation Svr '),
        'home_forward':    ('HOMF', 'Home Forward  '),
        'home_reverse':    ('HOMR', 'Home Reverse  '),
        'high_op_range':   ('HOPR', 'High Operating Range'),
        'high_severity':   ('HSV',  'High Severity '),
        'integral_gain':   ('ICOF', 'Integral Gain '),
        'jog_accel':       ('JAR',  'Jog Acceleration (EGU/s^2) '),
        'jog_forward':     ('JOGF', 'Jog motor Forward '),
        'jog_reverse':     ('JOGR', 'Jog motor Reverse'),
        'jog_speed':       ('JVEL', 'Jog Velocity '),
        'last_dial_val':   ('LDVL', 'Last Dial Des Val '),
        'low_limit':       ('LLM',  'User Low Limit  '),
        'low_limit_set':   ('LLS',  'At Low Limit Switch'),
        'lo_severity':     ('LLSV', 'Lolo Severity  '),
        'lolo_alarm':      ('LOLO', 'Lolo Alarm Limit  '),
        'low_op_range':    ('LOPR', 'Low Operating Range '),
        'low_alarm':       ('LOW', ' Low Alarm Limit '),
        'last_rel_val':    ('LRLV', 'Last Rel Value  '),
        'last_dial_drive': ('LRVL', 'Last Raw Des Val  '),
        'last_SPMG':       ('LSPG', 'Last SPMG  '),
        'low_severity':    ('LSV',  'Low Severity  '),
        'last_drive':      ('LVAL', 'Last User Des Val'),
        'soft_limit':      ('LVIO', 'Limit violation  '),
        'in_progress':     ('MIP',  'Motion In Progress '),
        'missed':          ('MISS', 'Ran out of retries '),
        'moving':          ('MOVN', 'Motor is moving  '),
        'resolution':      ('MRES', 'Motor Step Size (EGU)'),
        'motor_status':    ('MSTA', 'Motor Status  '),
        'offset':          ('OFF',  'User Offset (EGU) '),
        'output_mode':     ('OMSL', 'Output Mode Select  '),
        'output':          ('OUT',  'Output Specification '),
        'prop_gain':       ('PCOF', 'Proportional Gain '),
        'precision':       ('PREC', 'Display Precision '),
        'readback':        ('RBV',  'User Readback Value '),
        'retry_max':       ('RTRY', 'Max retry count    '),
        'retry_count':     ('RCNT', 'Retry count  '),
        'retry_deadband':  ('RDBD', 'Retry Deadband (EGU)'),
        'dial_difference': ('RDIF', 'Difference rval-rrbv '),
        'raw_encoder_pos': ('REP',  'Raw Encoder Position '),
        'raw_high_limit':  ('RHLS', 'Raw High Limit Switch'),
        'raw_low_limit':   ('RLLS', 'Raw Low Limit Switch'),
        'relative_value':  ('RLV',  'Relative Value    '),
        'raw_motor_pos':   ('RMP',  'Raw Motor Position '),
        'raw_readback':    ('RRBV', 'Raw Readback Value '),
        'readback_res':    ('RRES', 'Readback Step Size (EGU)'),
        'raw_drive':       ('RVAL', 'Raw Desired Value  '),
        'dial_speed':      ('RVEL', 'Raw Velocity '),
        's_speed':         ('S',    'Speed (RPS)  '),
        's_back_speed':    ('SBAK', 'Backlash Speed (RPS)  '),
        's_base_speed':    ('SBAS', 'Base Speed (RPS)'),
        's_max_speed':     ('SMAX', 'Max Velocity (RPS)'),
        'set':             ('SET',  'Set/Use Switch '),
        'stop_go':         ('SPMG', 'Stop/Pause/Move/Go '),
        's_revolutions':   ('SREV', 'Steps per Revolution '),
        'stop':            ('STOP', 'Stop  '),
        't_direction':     ('TDIR', 'Direction of Travel '),
        'tweak_forward':   ('TWF',  'Tweak motor Forward '),
        'tweak_reverse':   ('TWR',  'Tweak motor Reverse '),
        'tweak_val':       ('TWV',  'Tweak Step Size (EGU) '),
        'use_encoder':     ('UEIP', 'Use Encoder If Present'),
        'u_revolutions':   ('UREV', 'EGU per Revolution  '),
        'use_rdbl':        ('URIP', 'Use RDBL Link If Present'),
        'drive':           ('VAL',  'User Desired Value'),
        'base_speed':      ('VBAS', 'Base Velocity (EGU/s)'),
        'slew_speed':      ('VELO', 'Velocity (EGU/s) '),
        'version':         ('VERS', 'Code Version '),
        'max_speed':       ('VMAX', 'Max Velocity (EGU/s)'),
        'use_home':        ('ATHM', 'uses the Home switch'),
        'deriv_gain':      ('DCOF', 'Derivative Gain '),
        'use_torque':      ('CNEN', 'Enable torque control '),
        'device_type':     ('DTYP', 'Device Type'),
        'record_type':     ('RTYP', 'Record Type')}
        
## fields not implemented:
##    
    # VOF   Variable Offset
    # SSET  Set SET Mode 
    # STOO  STOP OutLink 
    # SUSE  Set USE Mode  
    # RLNK  Readback OutLink  
    # RINP  RMP Input Link 
    # CDIR  Command direction
    # DIFF  Difference dval-drbv
    # DOL   Desired Output Location
    # FOF   Freeze Offset  
    # MMAP  Monitor Mask  
    # NMAP  Monitor Mask  
    # POST  Post-move commands
    # PP    Post process command
    # PREM  Pre-move commands 
    # PERL  Periodic Limits
    # RDBL  Readback Location
    # INIT  Startup commands 
    
    __init_list = ('drive','description', 'readback','precision',
                   'tweak_val','tweak_forward','tweak_reverse',
                   'done_moving','set','stop', 'low_limit','high_limit',
                   'high_limit_set', 'low_limit_set', 'soft_limit')

    
    MotorException   = "EpicsMotor Exception"
        
    def __init__(self, name=None,timeout=1.):
        self._dat = {}
        self.valid= False
        if (not name):  raise self.MotorException, "must supply motor name"             

        if (name[-4:] == '.VAL'): name = name[:-4]
        self.pvname = name
        # make sure motor is enabled:
        try:
            p = PV("%s.RTYP" % name)
            if p.value != 'motor':
                raise self.MotorException, "%s is not an Epics Motor" % name
        except:
            raise self.MotorException, "%s is not an Epics Motor" %  name            
        
        self._dat['enable'] = PV("%s_able.VAL" % name)
        isEnabled = (0 == self._dat['enable'].get() )
        if not isEnabled: self._dat['enable'].put(0)        
        
        self.store_attributes(self.__init_list)
        
        self._dat['drive'].get()
        self.valid =  (self._dat['drive'].status == 0)

    def connect_all(self):
        for pv in self._dat.values():  pv.get()

    def __getattr__(self,attr):
        " internal method "
        if self.__motor_params.has_key(attr):
            return self.get_field(attr)
        elif (self.__dict__.has_key(attr)):
            return self.__dict__[attr]
        else:
            raise AttributeError, "EpicsMotor has no attribute %s" % attr
     
    def __setattr__(self,attr,val):
        if self.__motor_params.has_key(attr):
            # print ' Epics Motor SetAttr: ', attr, val
            return self.put_field(attr,val)
        else:
            self.__dict__[attr] = val

    def has_attr(self,attr):  return self._dat.has_key(attr)
    
    def store_attributes(self,attr_list):
        """store multiple attributes --
        first create PVs without connecting, then connect to all """
        for attr in attr_list:
            # print 'attr: ', attr
            pvlist = []
            if not self.has_attr(attr) and self.__motor_params.has_key(attr):
                pv = "%s.%s" % (self.pvname,self.__motor_params[attr][0])
                self._dat[attr] = PV(pv,connect=False)
                pvlist.append( self._dat[attr] )
        # now connect to all the PVs
        poll()
        for p in pvlist: p.get()
    
    def store_attr(self,attr):
        if not self.has_attr(attr) and self.__motor_params.has_key(attr):
            pv = "%s.%s" % (self.pvname,self.__motor_params[attr][0])
            self._dat[attr] = PV(pv,connect=True,connect_time=1.0)
        return self.has_attr(attr)
    

    def check_limits(self):
        """ check motor limits: raises expection if a limit is violated"""
        for l in (('soft_limit', 'Soft limit violation'),
                  ('high_limit_set'  , 'High hard limit violation'),
                  ('low_limit_set'  , 'Low  hard limit violation')):
            if (self.get_field(l[0]) != 0):
                raise self.MotorException, l[1]

    def move(self,val,relative=None,wait=1,dial=0,step=0,ignore_limits=0):
        """ moves motor to position"""
        # print ' Epics Motor Move: ', val, dial,step,relative
        val = float(val)
        if (val == None): return -1

        (drv,rbv) = ('drive','readback')
        if (dial != 0): (drv,rbv) = ('dial_drive','dial_readback')
        if (step != 0): (drv,rbv) = ('step_drive','step_readback')        

        if (relative):  val = val + self.get_field(rbv)
        self.put_field(drv,val)

        # Check for limit violations
        if (ignore_limits == 0): self.check_limits()


    def get_position(self, dial=0, readback=0, step=0):
        """
        Returns the target or readback motor position in user, dial or step
        coordinates.
      
      Keywords:
         readback:
            Set readback=1 to return the readback position in the
            desired coordinate system.  The default is to return the
            target position of the motor.
            
         dial:
            Set dial=1 to return the position in dial coordinates.
            The default is user coordinates.
            
         step:
            Set step=1 to return the position in steps.
            The default is user coordinates.

         Notes:
            The "step" and "dial" keywords are mutually exclusive.
            The "readback" keyword can be used in user, dial or step 
            coordinates.
            
      Examples:
        m=epicsMotor('13BMD:m38')
        m.move(10)                # Move to position 10 in user coordinates
        p=m.get_position(dial=1)  # Read the target position in dial coordinates
        p=m.get_position(readback=1, step=1) # Read the actual position in steps
        """
        # xx
        (drv,rbv) = ('drive','readback')
        if (dial != 0): (drv,rbv) = ('dial_drive','dial_readback')
        if (step != 0): (drv,rbv) = ('step_drive','step_readback')        
            
        if (readback != 0):
            return self.get_field(rbv)
        else:
            return self.get_field(drv)
        
    def tweak(self,dir='forward'):
        # print ' this is tweak ', dir
        if (dir == 'forward'):
            self.put_field('tweak_forward',1)
        elif (dir == 'reverse'):
            self.put_field('tweak_reverse',1)

        
    def set_position(self, position, dial=0, step=0):
        """
      Sets the motor position in user, dial or step coordinates.
      
      Inputs:
         position:
            The new motor position
            
      Keywords:
         dial:
            Set dial=1 to set the position in dial coordinates.
            The default is user coordinates.
            
         step:
            Set step=1 to set the position in steps.
            The default is user coordinates.
            
      Notes:
         The "step" and "dial" keywords are mutually exclusive.
         
      Examples:
         m=epicsMotor('13BMD:m38')
         m.set_position(10, dial=1)   # Set the motor position to 10 in 
                                      # dial coordinates
         m.set_position(1000, step=1) # Set the motor position to 1000 steps
         """

        # Put the motor in "SET" mode

        # print ' Epics Motor Set Position: ',  position, dial,step

        self.put_field('set',1)

      
        # determine which drive value to use
        drv = 'drive'
        if (dial != 0): drv = 'dial_drive'
        if (step != 0): drv = 'step_drive'

        self.put_field(drv,position)
        
        # Put the motor back in "Use" mode
        self.put_field('set',0)
      
    def wait(self, start=0, stop=0, poll=0.01, ignore_limits=0):
        """
        Waits for the motor to start moving and/or stop moving.
      
      Keywords:
         start:
            Set start=1 to wait for the motor to start moving.
            
         stop:
            Set stop=1 to wait for the motor to stop moving.
            
         poll:
            Set this keyword to the time to wait between reading the
            .DMOV field of the record to see if the motor is moving.
            The default is 0.01 seconds.
            
         ignore_limits:
            Set ignore_limits=1 to suppress raising an exception if a soft or
            hard limit is detected
            
      Notes:
         If neither the "start" nor "stop" keywords are set then "stop"
         is set to 1, so the routine waits for the motor to stop moving.
         If only "start" is set to 1 then the routine only waits for the
         motor to start moving.
         If both "start" and "stop" are set to 1 then the routine first
         waits for the motor to start moving, and then to stop moving.
         
      Examples:
         m=epicsMotor('13BMD:m38')
         m.move(100)               # Move to position 100
         m.wait(start=1, stop=1)   # Wait for the motor to start moving
                                   # and then to stop moving
        """
        if (start == 0) and (stop == 0): stop=1
        if (start != 0):
            while(1):
                done = self.get_field('done_moving')
                if (done != 1): break
                pend_io(poll)
                
        if (stop != 0):
            while(1):
                done = self.get_field('done_moving')
                if (done != 0): break
                pend_io(poll)
        if (ignore_limits == 0): self.check_limits()


    def stop(self):
        "stop motor right now"
        self.put_field('stop',1)

    def get_pv(self,attr):
        "return full PV for a field"
        if (not self._dat.has_key('drive')): return None
        if (self.__motor_params.has_key(attr) == 0):
            return None
        else:
            return "%s.%s" % (self.pvname,self.__motor_params[attr][0])

    def put_field(self,attr,val,wait=1):
        if not self.store_attr(attr): return None
        return self._dat[attr].put(val)

    def get_field(self,attr,use_char=False):
        if not self.store_attr(attr): return None
        return self._dat[attr].get(use_char=use_char)
    

    def clear_field_callback(self,attr):
        try:
            self._dat[attr].remove_callback(index=attr)
        except:
            self._dat[attr].clear_callbacks()

    def set_field_callback(self,attr,callback,kw={}):
        if not self.store_attr(attr): return None
        kw_args = {}
        kw_args['field'] = attr
        kw_args['motor'] = self
        kw_args.update(kw)
        self._dat[attr].set_callback(callback=callback,index=attr,**kw_args)

    def refresh(self):
        """ refresh all motor parameters currently in use:
        make sure all used attributes are up-to-date."""
        for i in self._dat.keys():
            if self.__motor_params.has_key(i):
                self.get_field(i)

    def lookup_attribute(self,suffix):
        """
        Reverse look-up of an attribute name given the PV suffix
        """
        suf = suffix.lower()
        if ((suf.find('.') == 0) or (suf.find('_') == 0)): suf =  suf[1:]
        for (name,ext) in  self.__motor_params.items():
            if (suf == ext[0].lower()): return name
        return None

    def show_all(self):
        """ show all motor attributes"""
        print " Motor %s [%s]\n" % (self.pvname,self.get_field('description'))
        print "   field      PV Suffix     value            description"
        print " ------------------------------------------------------------"
        list = self.__motor_params.keys()
        list.sort()
        for attr in list:
            l = attr 
            if (len(attr)<15): l  = l + ' '*(15-len(l))
            suf = self.__motor_params[attr][0]
            pv  = "%s.%s" % (self.pvname, suf)
            if (len(suf)<5): suf = suf  +' '*(5-len(suf))            
            val = self.get_field(attr,use_char=1)
            if (val):
                if (len(val)<12): val  = val + ' '*(12-len(val))
            print " %s  %s  %s  %s" % (l,suf,val,
                                       self.__motor_params[attr][1])


if (__name__ == '__main__'):
    import sys
    for i in sys.argv[1:]:
        x = EpicsMotor(i)
        print "Motor: ", x.pvname 
        #         for i in ('description', 'drive','readback', 'slew_speed',
        #                   'base_speed', 'direction','offset', 'precision',
        #                   'acceleration', 'resolution', 'high_limit', 'low_limit',
        #                   'dial_high_limit','dial_low_limit'):
        for i in ('description', 'drive','readback', 'slew_speed'):
            j = i
            if (len(j) < 16): j = "%s%s" % (j,' '*(16-len(j)))
            print "%s = %s" % (j, x.get_field(i,use_char=1))
        print "--------------------------------------"
