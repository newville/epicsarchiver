#!/usr/bin/env python
"""
"""
class closure:
    """A simple callback class to give a reference to a function with arguments
    that can be called later, optionally changing the argument list.  

    The class holds a function (the callback) which is executed when the class
    is called as a function. It can be defined as:

       >>>def my_action(x=None):
       ...        print 'my action: x = ', x
       >>>c = closure(my_action,x=1)
  
    and used as:
       >>>c()
       my action: x = 1
       >>>c(x=2)
        my action: x = 2

    The code is based on the Command class from J. Grayson's Tkinter book.
    """
    def __init__(self,func=None,*args, **kw):
        self.func  = func
        self.kw    = kw
        self.args  = args
        
    def __call__(self,  **kwd_args):
        if self.func is None: return None
        kwds = {}
        for k,v in self.kw.items():  kwds[k] = v
        for k,v in kwd_args.items(): kwds[k] = v
        return self.func(*self.args,**kwds)

